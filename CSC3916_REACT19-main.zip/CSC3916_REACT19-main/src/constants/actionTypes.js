const Constants = {
    USER_LOGGEDIN: 'USER_LOGGEDIN',
    USER_LOGOUT: 'USER_LOGOUT',
    FETCH_MOVIES: 'FETCH_MOVIES',
    FETCH_MOVIE: 'FETCH_MOVIE',
    SET_MOVIE: 'SET_MOVIE'
}

export default Constants;